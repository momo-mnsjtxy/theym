<center>
    <h1>用户密码重置</h1>
    <p style="font-size: 12px;color: grey">
        <?php echo e($username); ?>，您好！您正在申请重置<?php echo e($webName); ?>用户密码，请点击下面链接重新设置密码。<br>
        <a href="<?php echo e($url); ?>"><?php echo e($url); ?></a>
    </p>
</center><?php /**PATH /www/wwwroot/dns.wdvip.icu/src/resources/views/email/password.blade.php ENDPATH**/ ?>