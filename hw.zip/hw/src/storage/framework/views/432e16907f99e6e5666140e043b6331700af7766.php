<?php $__env->startSection('title', '记录列表'); ?>
<?php $__env->startSection('content'); ?>
    <div id="vue">
        <div class="layui-card">
            <div class="layui-card-body user-info-card">
                <div class="user-info-top text-center layui-text">
                    <div class="user-info-head">
                        <img src="../ajax/libs/images/avatar.svg"/>
                    </div>
                    <h2><?php echo e(auth()->user()->username); ?> - [<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>

                        ]</h2>
                </div>
                <div class="user-info-list layui-text">
                    <div class="info-list-item" lay-tips="邮箱" lay-direction="4">
                        <i class="layui-icon layui-icon-username"></i>
                        <p><?php echo e(auth()->user()->email); ?></p>
                    </div>
                    <div class="info-list-item" lay-tips="积分" lay-direction="4">
                        <i class="layui-icon layui-icon-note"></i>
                        <p><?php echo e(auth()->user()->point); ?> 积分</p>
                    </div>
                    <div class="info-list-item" lay-tips="用户名" lay-direction="4">
                        <i class="layui-icon layui-icon-auz"></i>
                        <p><?php echo e(auth()->user()->username); ?></p>
                    </div>
                    <div class="info-list-item" lay-tips="用户组" style="min-height: 21px;" lay-direction="4">
                        <i class="layui-icon layui-icon-layer"></i>
                        <p><?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="layui-card" style="margin-bottom:0px!important;">
            <div class="layui-tab layui-tab-brief ew-tab">
                <ul class="layui-tab-title">
                    <li class="layui-this"><a href="../home">解析记录</a></li>
                    <li class=""><a href="../home/point">积分明细</a></li>
                    <li class=""><a href="../home/profile">个人资料</a></li>
                </ul>
            </div>
            <div class="layui-card-body" style="box-sizing: border-box;padding-top: 5px;">
                <div class="layui-form-item" style="padding-top: 15px;">
                    <div class="text-center">
                        <a href="#modal-search" data-toggle="modal" class="layui-btn">搜索</a>
                        <a href="#modal-store" data-toggle="modal"
                           @click="storeInfo={did:domainList.length>0?domainList[0].did:0,line_id:0,type:'A'}"
                           class="layui-btn">添加</a>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="layui-table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>域名</th>
                            <th>记录类型</th>
                            <th>线路</th>
                            <th>记录值</th>
                            <th>添加时间</th>
                            <th>操作</th>
                        </tr>
                        </thead>
                        <tbody class="layui-table-body layui-table-main" v-cloak="">
                        <tr v-for="(row,i) in data.data" :key="i">
                            <td>{{ row.id }}</td>
                            <td>
                                <a :href="'http://'+row.name+'.'+(row.domain?row.domain.domain:'')" target="_blank">
                                    {{ row.name }}.{{ row.domain?row.domain.domain:'' }}
                                </a>
                            </td>
                            <td>{{ row.type }}</td>
                            <td>{{ row.line }}</td>
                            <td>{{ row.value }}</td>
                            <td>{{ row.created_at }}</td>
                            <td>
                                <a href="#modal-store" class="layui-btn layui-btn-primary" data-toggle="modal"
                                   @click="storeInfo=Object.assign({},row)">修改
                                </a>
                                <a class="layui-btn" style="color:#fff!important;" @click="del(row.id)">删除</a>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="pb-0 text-center">
                <?php echo $__env->make('admin.layout.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="modal fade" id="modal-search">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">记录搜索</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="text" disabled="disabled" class="d-none">
                            <div class="layui-form-item">
                                <label class="layui-form-label">后缀:</label>
                                <div class="layui-input-block">
                                    <select class="layui-input" v-model="search.did">
                                        <option value="0">所有</option>
                                        <option v-for="(domain,i) in domainList" :value="domain.did">{{ domain.domain
                                            }}
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">类型:</label>
                                <div class="layui-input-block">
                                    <select class="layui-input" v-model="search.type">
                                        <option value="0">所有</option>
                                        <option value="A">A记录</option>
                                        <option value="CNAME">CANME</option>
                                    </select>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">记录:</label>
                                <div class="layui-input-block">
                                    <input type="text" placeholder="主机记录" class="layui-input" v-model="search.name">
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">记录值:</label>
                                <div class="layui-input-block">
                                    <input type="text" placeholder="记录值" class="layui-input" v-model="search.value">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="layui-btn layui-btn-primary" data-dismiss="modal">关闭</button>
                            <button type="button" class="layui-btn" @click="getList(1)">搜索</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="modal-store">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">记录添加/修改</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="form-store">
                            <input type="hidden" name="action" value="recordStore">
                            <input type="hidden" name="id" :value="storeInfo.id" v-if="storeInfo.id">
                            <input type="hidden" name="did" :value="storeInfo.did" v-if="storeInfo.id">
                            <div class="layui-form-item">
                                <label class="layui-form-label">记录:</label>
                                <div class="layui-input-block">
                                    <input type="text" name="name" class="layui-input" placeholder="输入前缀"
                                           v-model="storeInfo.name">
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">后缀:</label>
                                <div class="layui-input-block">
                                    <select class="layui-input" name="did"
                                            v-model="storeInfo.did" :disabled="storeInfo.id">
                                        <option v-for="(domain,i) in domainList" :value="domain.did">
                                            {{ domain.domain }}
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">说明:</label>
                                <div class="layui-input-block">
                                    <div
                                        style="border:solid 1px #ced4da;border-radius:2px;padding: .375rem .75rem;margin-top: .25rem;font-size: 14px;color: grey;"
                                        v-if="desc"
                                        v-html="desc"></div>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">记录值:</label>
                                <div class="layui-input-block">
                                    <input type="text" name="value" class="layui-input" placeholder="输入记录值"
                                           v-model="storeInfo.value">
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">类型:</label>
                                <div class="layui-input-block">
                                    <select class="layui-input" name="type" v-model="storeInfo.type">
                                        <option value="A">A</option>
                                        <option value="CNAME">CNAME</option>
                                    </select>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">线路:</label>
                                <div class="layui-input-block">
                                    <select class="layui-input" name="line_id" v-model="storeInfo.line_id">
                                        <option v-for="(line,i) in getLineList()" :value="line.Id">
                                            {{ line.Name }}
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">积分:</label>
                                <div class="layui-input-block">
                                    <input type="text" class="layui-input" style="background-color:#F5F5F5!important;"
                                           :value="getDomainPoint()+' 积分/条 - 用户总积分：<?php echo e(auth()->user()->point); ?>'"
                                           disabled>
                                </div>
                            </div>
                    </div>
                    </form>
                    <div class="modal-footer">
                        <button type="button" class="layui-btn layui-btn-primary" data-dismiss="modal">关闭</button>
                        <button type="button" class="layui-btn" @click="form('store')">确认</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="ew-footer" style="max-width: 100vw;overflow: hidden;">
        <div class="layui-container">
            <div class="layui-row layui-col-space30">
                <div class="layui-col-md6">
                    <h2 style="font-size: 17px;" class="footer-item-title">关于我们</h2>
                    <p><span>Copyright© 2023 <?php echo e(config('sys.web.name')); ?> .all rights reserved.</span></p>
                </div>
                <div class="layui-col-md4">
                    <h2 style="font-size: 17px;" class="footer-item-title">联系我们</h2>
                    <p>
                        <i class="layui-icon layui-icon-login-qq"></i>
                        <a href="http://wpa.qq.com/msgrd?v=3&uin=3636066488&site=qq&menu=yes" target="_blank">咨询在线客服QQ:188974297</a>
                    </p>
                </div>
                <div class="layui-col-md2">
                    <h2 style="font-size: 17px;" class="footer-item-title">相关链接</h2>
                    <p><i class="layui-icon layui-icon-component"></i><a href="www.lkdns.top"
                                                                         target="_blank">灵空官网</a></p>
                </div>
            </div>
            <div style="padding: 15px 0!important;"></div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
    <script>
        new Vue({
            el: '#vue',
            data: {
                search: {
                    page: 1, did: 0, name: '', type: 0, value: ''
                },
                domainList: [],
                data: {},
                storeInfo: {
                    did: 0,
                    line_id: 0
                },
                selectDid: 0,
                desc: ''
            },
            methods: {
                getDomainPoint: function () {
                    var vm = this;
                    for (var i = 0; i < this.domainList.length; i++) {
                        if (this.domainList[i].did === this.storeInfo.did) {
                            vm.desc = this.domainList[i].desc;
                            return this.domainList[i].point;
                        }
                    }
                    return 0;
                },
                getLineList: function () {
                    for (var i = 0; i < this.domainList.length; i++) {
                        if (this.domainList[i].did === this.storeInfo.did) {
                            if (this.selectDid != this.storeInfo.did) {
                                this.storeInfo.line_id = this.domainList[i].line[0].Id;
                                this.selectDid = this.storeInfo.did
                            }
                            return this.domainList[i].line;
                        }
                    }
                    return [{Name: '默认', Id: 0}];
                },
                getList: function (page) {
                    var vm = this;
                    vm.search.page = typeof page === 'undefined' ? vm.search.page : page;
                    this.$post("/home", vm.search, {action: 'recordList'})
                        .then(function (data) {
                            if (data.status === 0) {
                                vm.data = data.data
                            } else {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            }
                        })
                },
                getDomainList: function (page) {
                    var vm = this;
                    this.$post("/home", vm.search, {action: 'domainList'})
                        .then(function (data) {
                            if (data.status === 0) {
                                vm.domainList = data.data
                            } else {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            }
                        })
                },
                form: function (id) {
                    var vm = this;
                    this.$post("/home", $("#form-" + id).serialize())
                        .then(function (data) {
                            if (data.status === 0) {
                                vm.getList();
                                $("#modal-" + id).modal('hide');
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            } else {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            }
                        });
                },
                del: function (id) {
                    if (!confirm('确认删除？')) return;
                    var vm = this;
                    this.$post("/home", {action: 'recordDelete', id: id})
                        .then(function (data) {
                            if (data.status === 0) {
                                vm.getList();
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            } else {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            }
                        });
                },
            },
            mounted: function () {
                this.getDomainList();
                this.getList();
            }
        });
        $.confirm({
            title: '官方公告',
            icon: 'mdi mdi-rocket',
            content: '<?php if(config('sys.html_home')): ?><?php echo config('sys.html_home'); ?><?php endif; ?>',
            type: 'blue',
            buttons: {
                omg: {
                    text: '我已知晓',
                    btnClass: 'btn-blue',
                },
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.1.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/home/1/index.blade.php ENDPATH**/ ?>