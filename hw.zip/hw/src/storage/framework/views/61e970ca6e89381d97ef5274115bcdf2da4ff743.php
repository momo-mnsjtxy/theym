<?php $__env->startSection('title', '积分明细'); ?>
<?php $__env->startSection('content'); ?>
<div id="vue">
<div class="layui-card">
<div class="layui-card-body user-info-card">
<div class="user-info-top text-center layui-text">
<div class="user-info-head">
<img src="../ajax/libs/images/avatar.svg"/>
</div>
<h2><?php echo e(auth()->user()->username); ?> - [<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>]</h2>
</div>
<div class="user-info-list layui-text">
<div class="info-list-item" lay-tips="邮箱" lay-direction="4">
<i class="layui-icon layui-icon-username"></i>
<p><?php echo e(auth()->user()->email); ?></p>
</div>
<div class="info-list-item" lay-tips="积分" lay-direction="4">
<i class="layui-icon layui-icon-note"></i>
<p><?php echo e(auth()->user()->point); ?> 积分</p>
</div>
<div class="info-list-item" lay-tips="用户名" lay-direction="4">
<i class="layui-icon layui-icon-auz"></i>
<p><?php echo e(auth()->user()->username); ?></p>
</div>
<div class="info-list-item" lay-tips="用户组" style="min-height: 21px;" lay-direction="4">
<i class="layui-icon layui-icon-layer"></i>
<p><?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?></p>
</div>
</div>
</div>
</div>
<div class="layui-card">
<div class="layui-tab layui-tab-brief ew-tab">
<ul class="layui-tab-title">
<li class=""><a href="../home">解析记录</a></li>
<li class="layui-this"><a href="../home/point">积分明细</a></li>
<li class=""><a href="../home/profile">个人资料</a></li>
</ul>
</div>
<div class="layui-card-body">
<input type="text" disabled="disabled" class="d-none">
<div class="layui-form-item">
<select class="layui-input" style="float:left;width:60%;" v-model="search.act">
<option value="all">所有</option>
<option value="increase">增加</option>
<option value="reduce">减少</option>
<option value="消费">消费</option>
</select>
<a class="layui-btn" style="color:#fff!important;float:right;width:35%;" @click="getList(1)"> 搜索</a>
</div>
<div class="table-responsive">
<table class="layui-table">
<thead>
<tr>
<th>ID</th>
<th>操作</th>
<th>积分</th>
<th>剩余</th>
<th>详情</th>
<th>时间</th>
</tr>
</thead>
<tbody v-cloak="">
<tr v-for="(row,i) in data.data" :key="i"
:class="{'text-danger':row.point<0,'text-success':row.point>0}">
<td>{{ row.id }}</td>
<td>{{ row.action }}</td>
<td>{{ row.point }}</td>
<td>{{ row.rest }}</td>
<td>{{ row.remark }}</td>
<td>{{ row.created_at }}</td>
</tr>
</tbody>
</table>
</div>
</div>
<div class="pb-0 text-center">
<?php echo $__env->make('admin.layout.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
</div>
</div>
</div>
<div class="ew-footer" style="max-width: 100vw;overflow: hidden;">
<div class="layui-container">
<div class="layui-row layui-col-space30">
<div class="layui-col-md6">
<h2 style="font-size: 17px;" class="footer-item-title">关于我们</h2>
<p> <span>Copyright© 2023 <?php echo e(config('sys.web.name')); ?> .all rights reserved.</span></p>
</div>
<div class="layui-col-md4">
<h2 style="font-size: 17px;" class="footer-item-title">联系我们</h2>
<p>
<i class="layui-icon layui-icon-login-qq"></i>
<a href="http://wpa.qq.com/msgrd?v=3&uin=3636066488&site=qq&menu=yes" target="_blank">咨询在线客服QQ:188974297</a>
</p>
</div>
<div class="layui-col-md2">
<h2 style="font-size: 17px;" class="footer-item-title">相关链接</h2>
<p><i class="layui-icon layui-icon-component"></i><a href="www.lkdns.top" target="_blank">灵空官网</a></p>
</div>
</div>
<div style="padding: 15px 0!important;"></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
<script>
new Vue({
el: '#vue',
data: {
search: {
page: 1, uid: $_GET('uid'), act: 'all'
},
data: {},
storeInfo: {}
},
methods: {
getList: function (page) {
var vm = this;
vm.search.page = typeof page === 'undefined' ? vm.search.page : page;
this.$post("/home", vm.search, {action: 'pointRecord'})
.then(function (data) {
if (data.status === 0) {
vm.data = data.data
} else {
$.confirm({
title: '信息',
icon: 'mdi mdi-information-outline',
content: (data.message),
type: 'blue',
buttons: {
omg: {
text: '确定',
btnClass: 'btn-blue',
},
}
});
}
})
},
},
mounted: function () {
this.getList();
}
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('1.home.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/1/home/point.blade.php ENDPATH**/ ?>