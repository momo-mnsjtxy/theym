<?php $__env->startSection('title', '个人资料'); ?>
<?php $__env->startSection('content'); ?>
    <div id="vue">
        <div class="layui-card">
            <?php echo $__env->make('home.lkdns.layout.hand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="layui-card">
            <div class="layui-tab layui-tab-brief ew-tab">
                <ul class="layui-tab-title">
                    <li class=""><a href="../home">解析记录</a></li>
                    <li class=""><a href="../home/point">积分明细</a></li>
                    <li class=""><a href="/home/recharge">积分充值</a></li>
                    <li class=""><a href="../home/profile">个人资料</a></li>
                    <li class=""><a href="../home/srv">SRV生成器</a></li>
                    <li class="layui-this"><a href="../home/hd">活动</a></li>
                </ul>
            </div>
            <div class="layui-card-body" style="box-sizing: border-box;padding-top: 5px;" id="ac">
                <br>
                <form id="form-profile">
                    <input type="hidden" name="action" value="profile">
                    <div class="layui-form-item">
                        <label class="layui-form-label">点击领取:</label>
                        <div class="layui-input-block">
                            <a class="layui-btn" style="color:#fff!important;" @click="activity()">点击领取</a>
                        </div>
                    </div>
                </form>
                <div class="layui-form-item" style="padding-top: 15px;">
                    <div class="layui-input-block text-center">
                        <a class="layui-btn layui-btn-primary" href="/home">首页</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
    <script>
        new Vue({
            el: '#ac',
            data: {},
            methods: {
                activity: function () {
                    var vm = this;
                    this.$post("/home", {action: 'activity'})
                        .then(function (data) {
                            if (data.status === 0) {
                                vm.$notify({
                                    title: '成功',
                                    message: (data.message),
                                    type: 'success',
                                    duration: 3000,
                                });
                            } else {
                                vm.$notify.error({
                                    title: '错误',
                                    message: (data.message),
                                    duration: 3000,
                                });
                            }
                        });
                },
            },
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.lkdns.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/home/lkdns/dh.blade.php ENDPATH**/ ?>