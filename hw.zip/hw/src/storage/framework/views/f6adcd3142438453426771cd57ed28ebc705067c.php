<?php $__env->startSection('title', '活动'); ?>
<?php $__env->startSection('content'); ?>
    <div style="text-align:center;" class="lyear-login">
        <div class="card-inner animated active" id="about-card">
            <div class="col col-d-12 col-t-12 col-m-12 border-line-v">
                <div class="text-box">
                    <div class="alert alert-primary" style="color:red;">
                        <?php echo e(config('sys.activity.html')); ?>

                    </div>
                </div>
            </div>
            <div id="form1" class="login-center">
                <h1>活动</h1>
                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                        <td width="500" height="50" style="color:red;">
                            <h1>点击下方按钮即可领取奖励</h1>
                            <input @click="activity()" type="submit" name="login" class="btn btn-block btn-success" value="领取" />
                    </tr>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
        <script>
            new Vue({
                el: '#form1',
                data: {
                    data: {},
                    storeInfo: {}
                },
                methods: {
                    activity: function () {
                        this.$post("/home", {action: 'activity'})
                            .then(function (data) {
                                var vm = this;
                                if (data.status === 0) {
                                    layer.alert(data.message,{title:"领取成功"});
                                } else {
                                    layer.alert(data.message,{title:"领取失败"});
                                }
                            })
                    },
                },
            });
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/home/dh.blade.php ENDPATH**/ ?>