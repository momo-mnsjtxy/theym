<?php $__env->startSection('title', '积分充值'); ?>
<?php $__env->startSection('content'); ?>
<div id="vue" class="pt-3 pt-sm-0">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">当前积分【<?php echo e(auth()->user()->point); ?>】-- 积分充值 - 比例：1:<?php echo e(config('sys.1')); ?></div>
          <div class="card-body">
            <form action="/pay/epayapi.php" method="post">
              <div class="form-group row">
                <input type="hidden" name="uid" value="<?php echo e(auth()->user()->uid); ?>">
                <input type="hidden" name="WIDout_trade_no" value="<?php echo date("YmdHis").mt_rand(100,999); ?>">
                <input type="hidden" size="30" name="WIDsubject" value="积分充值-<?php echo e(auth()->user()->uid); ?>">
                <label for="staticEmail" class="col-sm-1 col-form-label">充值金额</label>
                <div class="col-sm-9">
                  <input type="text" name="WIDtotal_fee" placeholder="充值金额 0.01~500" class="form-control">
                </div>
                <div class="col-lg-2">
                  <input type="submit" class="btn btn-info ml-1" value="充值" >
                </div>
                <div class="col-lg-12">
                    <label>
                    <input type="radio" name="type" value="alipay" checked="checked">支付宝&nbsp;
                    <input type="radio" name="type" value="wxpay">微信&nbsp;
                    </label>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="vue" class="pt-3 pt-sm-0">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">当前状态【<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>】-- 会员充值 - 价格：<?php echo e(config('sys.user.vip',0)); ?>/永久</div>
          <div class="card-body">
            <form action="/pay/hy/epayapi.php" method="post">
              <div class="form-group row">
                <input type="hidden" name="uid" value="<?php echo e(auth()->user()->uid); ?>">
                <input type="hidden" name="WIDout_trade_no" value="<?php echo date("YmdHis").mt_rand(100,999); ?>">
                <input type="hidden" size="30" name="WIDsubject" value="会员充值-<?php echo e(auth()->user()->uid); ?>">
                <label for="staticEmail" class="col-sm-1 col-form-label" value="<?php echo e(config('sys.user.vip',0)); ?>">充值时间</label>
                <label>
                    <input type="radio" name="WIDtotal_fee" value="<?php echo e(config('sys.user.vip',0)); ?>" checked="checked"><?php echo e(config('sys.user.vip',0)); ?>/永久
                </label>
                <div class="col-lg-2">
                  <input type="submit" class="btn btn-info ml-1" value="充值" >
                </div>
                <div class="col-lg-12">
                    <label>
                    <input type="radio" name="type" value="alipay" checked="checked">支付宝&nbsp;
                    <input type="radio" name="type" value="wxpay">微信&nbsp;
                    </label>
                </div>
                <div>会员特权
                    1.所有解析2折(原价/5)
                    2.赠送466积分(原300)
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="vue" class="pt-3 pt-sm-0">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header"><?php echo date("n").'月'; ?>积分抽奖(每月10次) - 价格：￥1.88 /一次</div>
          <div class="card-body">
            <form action="/pay/cj/epayapi.php" method="post">
              <div class="form-group row">
                <input type="hidden" name="uid" value="<?php echo e(auth()->user()->uid); ?>">
                <input type="hidden" name="WIDout_trade_no" value="<?php echo date("YmdHis").mt_rand(100,999); ?>">
                <input type="hidden" size="30" name="WIDsubject" value="限时抽奖-<?php echo e(auth()->user()->uid); ?>">
                <label for="staticEmail" class="col-sm-1 col-form-label" value="<?php echo e(config('sys.user.vip',0)); ?>">充值时间</label>
                <label>
                    <input type="radio" name="WIDtotal_fee" value="1.88" checked="checked"> ￥1.88/一次
                </label>
                <div class="col-lg-2">
                  <input type="submit" class="btn btn-info ml-1" value="支付抽奖" >
                </div>
                <div class="col-lg-12">
                    <label>
                    <input type="radio" name="type" value="alipay" checked="checked">支付宝&nbsp;
                    <input type="radio" name="type" value="wxpay">微信&nbsp;
                    </label>
                </div>
                <div>奖品: 128,168,188,238,288,388,488,688
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/home/recharge.blade.php ENDPATH**/ ?>