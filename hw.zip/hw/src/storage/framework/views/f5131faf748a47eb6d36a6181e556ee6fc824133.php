<?php $__env->startSection('title', 'SRV生成器'); ?>
<?php $__env->startSection('content'); ?>
    <script type="text/javascript">
        function _0xb497(_0x4a5591,_0x1db2f6){var _0x151534=_0x5592();return _0xb497=function(_0x222ab1,_0x262215){_0x222ab1=_0x222ab1-(-0x2d4*-0x2+0xeff+-0x12ee);var _0x552908=_0x151534[_0x222ab1];return _0x552908;},_0xb497(_0x4a5591,_0x1db2f6);}var _0x4bbf95=_0xb497;function _0x5592(){var _0x40fd79=['host','JxyFy','alias','wPBLt','hNuha','AwDLj','OXxNQ','bBmHH','gRJdS','onclick','357siFeXE','2148723yEBeXn','cxNUW','RfDST','mSHlF','qQFmo','120450gsxmKM','value','qvLlE','xkAVl','service','hostte','24730mjSHpd','AFNBz','record','protocol','zgFSy','pwjRt','8|5|4|7|3|','PaeRL','mxBEt','priority','16lWIjck','45680990FjQKgL','weight','3228668IEfkgT','记录值有内容为空哦','0|10|1|9|2','YTpAa','1527211BGCXxJ','KMdNZ','port','onload','getElement','ById','3225165rplvGy','split','coJmK','主机记录有内容为空哦','rXPFn','byJFr','16aYnOsU'];_0x5592=function(){return _0x40fd79;};return _0x5592();}(function(_0x24762c,_0x595afa){var _0x428703=_0xb497,_0x5c6eff=_0x24762c();while(!![]){try{var _0x627f41=-parseInt(_0x428703(0x1dc))/(0x3e1+-0x5df+0x1ff)+-parseInt(_0x428703(0x1d8))/(-0x1689*0x1+-0x1c32+0x32bd)+-parseInt(_0x428703(0x1e2))/(0x21d*-0xe+0xb31+-0x1f*-0x98)+parseInt(_0x428703(0x1d5))/(-0x3*0xb83+-0xbce+0x2e5b*0x1)*(parseInt(_0x428703(0x1cb))/(-0x26*-0xeb+0x2431+-0xaa*0x6b))+parseInt(_0x428703(0x1c5))/(-0xa23+0xd52+-0x329*0x1)*(parseInt(_0x428703(0x1bf))/(-0x1418+-0x2*-0xd74+-0x6c9))+parseInt(_0x428703(0x1e8))/(-0x450+0xc1*-0x3+0x13*0x59)*(-parseInt(_0x428703(0x1c0))/(-0x75b*0x5+-0x135d+-0x1*-0x382d))+parseInt(_0x428703(0x1d6))/(-0x23ea+-0x1c52+-0x2023*-0x2);if(_0x627f41===_0x595afa)break;else _0x5c6eff['push'](_0x5c6eff['shift']());}catch(_0x509f76){_0x5c6eff['push'](_0x5c6eff['shift']());}}}(_0x5592,-0x9a980+-0x2b233*0x5+0x2524ed),window[_0x4bbf95(0x1df)]=function(){var _0x23acb2=_0x4bbf95,_0x214b92={'RfDST':_0x23acb2(0x1d1)+_0x23acb2(0x1da)+'|6','OXxNQ':_0x23acb2(0x1cd),'YTpAa':_0x23acb2(0x1d7),'KMdNZ':_0x23acb2(0x1e9),'gRJdS':function(_0x3ec5b5,_0x56dc74){return _0x3ec5b5==_0x56dc74;},'coJmK':_0x23acb2(0x1e5),'cxNUW':function(_0x54f098,_0x2d06e9){return _0x54f098==_0x2d06e9;},'wPBLt':function(_0x55bc07,_0x35700f){return _0x55bc07===_0x35700f;},'qvLlE':function(_0x34fe99,_0x589223){return _0x34fe99+_0x589223;},'JxyFy':_0x23acb2(0x1eb),'mSHlF':_0x23acb2(0x1ce),'qQFmo':function(_0x2667b9,_0x2db2a9){return _0x2667b9===_0x2db2a9;},'pwjRt':_0x23acb2(0x1d9),'zgFSy':function(_0x3029a2,_0xf82261){return _0x3029a2===_0xf82261;},'PaeRL':function(_0x368b0a,_0xc9d02e){return _0x368b0a+_0xc9d02e;},'bBmHH':function(_0x3bcd37,_0x198ad5){return _0x3bcd37+_0x198ad5;},'hNuha':function(_0x8b4279,_0xbdeaf7){return _0x8b4279+_0xbdeaf7;},'xkAVl':function(_0x5af464,_0x2f4e84){return _0x5af464+_0x2f4e84;},'byJFr':function(_0x2d964a,_0x5d3e9e){return _0x2d964a+_0x5d3e9e;},'mxBEt':_0x23acb2(0x1ca),'AFNBz':_0x23acb2(0x1c9),'AwDLj':_0x23acb2(0x1de),'rXPFn':_0x23acb2(0x1d4)},_0x249569=document[_0x23acb2(0x1e0)+_0x23acb2(0x1e1)]('sc');_0x249569[_0x23acb2(0x1be)]=function(){var _0x37a0a4=_0x23acb2,_0x58927e=_0x214b92[_0x37a0a4(0x1c2)][_0x37a0a4(0x1e3)]('|'),_0x222a7b=0xc19+0x249b+0x6*-0x81e;while(!![]){switch(_0x58927e[_0x222a7b++]){case'0':var _0x580d5b=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1bb)]);continue;case'1':var _0x1590bd=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1db)])[_0x37a0a4(0x1c6)];continue;case'2':var _0x49bb68=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1dd)])[_0x37a0a4(0x1c6)];continue;case'3':if(_0x214b92[_0x37a0a4(0x1bd)](_0x50032d,''))_0xf545f[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1e4)];else{if(_0x214b92[_0x37a0a4(0x1c1)](_0x1b8382,''))_0xf545f[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1e4)];else{if(_0x214b92[_0x37a0a4(0x1ec)](_0x3917cc,''))_0xf545f[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1e4)];else _0x214b92[_0x37a0a4(0x1ec)](_0xf545f,'')?_0xf545f[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1e4)]:_0xf545f[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1c7)](_0x214b92[_0x37a0a4(0x1c7)](_0x214b92[_0x37a0a4(0x1c7)](_0x214b92[_0x37a0a4(0x1c7)](_0x214b92[_0x37a0a4(0x1c7)]('_',_0x50032d),'._'),_0x1b8382),'.'),_0x3917cc);}}continue;case'4':var _0x3917cc=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1ea)])[_0x37a0a4(0x1c6)];continue;case'5':var _0x1b8382=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1c3)])[_0x37a0a4(0x1c6)];continue;case'6':if(_0x214b92[_0x37a0a4(0x1c4)](_0xaab49c,''))_0x580d5b[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1d0)];else{if(_0x214b92[_0x37a0a4(0x1c4)](_0x1590bd,''))_0x580d5b[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1d0)];else{if(_0x214b92[_0x37a0a4(0x1ec)](_0x39597c,''))_0x580d5b[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1d0)];else _0x214b92[_0x37a0a4(0x1cf)](_0x49bb68,'')?_0x580d5b[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1d0)]:_0x580d5b[_0x37a0a4(0x1c6)]=_0x214b92[_0x37a0a4(0x1d2)](_0x214b92[_0x37a0a4(0x1bc)](_0x214b92[_0x37a0a4(0x1b9)](_0x214b92[_0x37a0a4(0x1d2)](_0x214b92[_0x37a0a4(0x1c8)](_0x214b92[_0x37a0a4(0x1c7)](_0x214b92[_0x37a0a4(0x1e7)](_0xaab49c,'\x20'),_0x1590bd),'\x20'),_0x39597c),'\x20'),_0x49bb68),'.');}}continue;case'7':var _0xf545f=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1d3)]);continue;case'8':var _0x50032d=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1cc)])[_0x37a0a4(0x1c6)];continue;case'9':var _0x39597c=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1ba)])[_0x37a0a4(0x1c6)];continue;case'10':var _0xaab49c=document[_0x37a0a4(0x1e0)+_0x37a0a4(0x1e1)](_0x214b92[_0x37a0a4(0x1e6)])[_0x37a0a4(0x1c6)];continue;}break;}};});
    </script>
    <div class="container">
        <div class="row">
            <div class="col-12 py-md-3 pl-md-5">
                <div class="card mb-3">
                    <div class="bd-b card-header text-white bg-info">SRV生成器(无特殊均为小写)</div>
                    <div class="card-body">
                        <form id="form" style="margin-top: 0; margin-bottom: 0px;">
                            <div class="form-group text-center">
                                <div style="border: 1px solid rgb(206, 212, 218);border-radius: 0.25rem;padding: 0.375rem 0.75rem;margin-top: 0.25rem;font-size: 30px;color: grey;text-align: center;margin: 0 auto;width: 95%;">主机记录</div>
                            </div>
                            <div class="form-group row">
                                <label for="service" class="col-5 col-form-label">服务名(如:minecraft,frp,ssh)</label>
                                <div class="col-7">
                                    <input type="text" id="service" class="form-control" placeholder="输入服务名" value="minecraft">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="protocol" class="col-5 col-form-label">协议名(如:tcp、udp)</label>
                                <div class="col-7">
                                    <input type="text" id="protocol" class="form-control" placeholder="输入协议名" value="tcp">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="alias" class="col-5 col-form-label">前缀(二级域名前缀)</label>
                                <div class="col-7">
                                    <input type="text" id="alias" class="form-control" placeholder="输入前缀">
                                </div>
                            </div>
                            <div class="form-group text-center">
                                <div style="border: 1px solid rgb(206, 212, 218);border-radius: 0.25rem;padding: 0.375rem 0.75rem;margin-top: 0.25rem;font-size: 30px;color: grey;text-align: center;margin: 0 auto;width: 95%;">记录值</div>
                            </div>
                            <div class="form-group row">
                                <label for="priority" class="col-5 col-form-label">优先级:(值越小，优先级越高)</label>
                                <div class="col-7">
                                    <input type="text" id="priority" class="form-control" placeholder="输入优先级" value="10">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="weight" class="col-5 col-form-label">权重:(值越大,权重越大)</label>
                                <div class="col-7">
                                    <input type="text" id="weight" class="form-control" placeholder="输入权重" value="5">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="port" class="col-5 col-form-label">端口号:(服务的端口,如ssh为22)</label>
                                <div class="col-7">
                                    <input type="text" id="port" class="form-control" placeholder="输入端口号">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="host" class="col-5 col-form-label">主机名:(目标主机的域名或ip。请确定可以访问)</label>
                                <div class="col-7">
                                    <input type="text" id="host" class="form-control" placeholder="输入目标主机名">
                                </div>
                            </div>
                            <div class="form-group text-center">
                                <a class="btn btn-info text-white" id="sc" href="#modal-srv" data-toggle="modal"> 生 成 </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-srv">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">生成完成</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form-store">
                        <div class="form-group row">
                            <label for="h" class="col-sm-3 col-form-label">主机记录</label>
                            <div class="col-sm-7">
                                <div class="input-group">
                                    <input type="text" name="hostte" id="hostte" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="staticEmail" class="col-sm-6 col-form-label">记录类型</label>
                            <div class="col-sm-5">
                                <option value="SRV">SRV</option>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="record" class="col-sm-3 col-form-label">记录值</label>
                            <div class="col-sm-7">
                                <input type="text" id="record" placeholder="" class="form-control">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                    <button type="button" class="btn btn-primary" data-dismiss="modal">确认</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.lkdns.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/home/lkdns/srv.blade.php ENDPATH**/ ?>