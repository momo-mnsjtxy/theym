<?php $__env->startSection('title', '后台首页'); ?>
<?php $__env->startSection('content'); ?>
    <div id="vue" class="pt-3 pt-sm-0">
        <div class="card">
            <div class="card-header">
                添加域名简单教程
            </div>
            <div class="card-body">
                <div class="list-group-item">
                    1、点击菜单栏的<a href="/admin/config/dns">接口配置</a>，先对你使用的域名解析平台的接口进行配置！
                </div>
                <div class="list-group-item">
                    2、点击菜单栏的<a href="/admin/domain/list">域名列表</a>，然后点击添加》选择你配置的解析平台》获取，然后选择你要添加的域名，然后保存！
                </div>
            </div>
        </div>
    </div>
    <div id="vue">
        <div class="card">
            <div class="card-header">
                服务器信息
            </div>
            <div class="card-body">
                <div class="list-group-item">
                    Laravel版本：<?php echo e(app()->version()); ?><br>
                    服务器版本：<?php echo e(php_uname('s').php_uname('r')); ?><br>
                    PHP版本：<?php echo e(PHP_VERSION); ?><br>
                    服务器环境：<?php echo e($_SERVER['SERVER_SOFTWARE']); ?><br>
                    服务器IP：<?php echo e($_SERVER['SERVER_ADDR']); ?><br>
                    服务器域名：<?php echo e($_SERVER['SERVER_NAME']); ?><br>
                    服务器端口：<?php echo e($_SERVER['SERVER_PORT']); ?><br>
                    服务器系统目录：<?php echo e($_SERVER['SystemRoot']); ?><br>
                    服务器当前时间：<?php echo e(date('Y-m-d H:i:s')); ?><br>
                    服务器语言：<?php echo e($_SERVER['HTTP_ACCEPT_LANGUAGE']); ?><br>
                    服务器CPU类型：<?php echo e($_SERVER['PROCESSOR_ARCHITECTURE']); ?><br>
                    服务器硬盘信息：<?php echo e($_SERVER['SystemRoot']); ?><br>
                    服务器用户名：<?php echo e($_SERVER['USERNAME']); ?><br>
                    服务器用户组：<?php echo e($_SERVER['USERDOMAIN']); ?><br>
                    服务器剩余空间：<?php echo e(round((@disk_free_space(".")/(1024*1024)),2)); ?>M<br>
                    服务器已用空间：<?php echo e(round((@disk_total_space(".")/(1024*1024)),2)); ?>M<br>
                    服务器总共空间：<?php echo e(round((@disk_free_space(".")/(1024*1024)),2)); ?>M<br>
                    服务器已用空间占比：<?php echo e(round(((@disk_free_space(".")/@disk_total_space("."))*100),2)); ?>%<br>
                    服务器PHP已用内存：<?php echo e(round((memory_get_usage()/1024/1024),2)); ?>M<br>
                    服务器PHP最大内存：<?php echo e(get_cfg_var("memory_limit")); ?><br>
                    服务器POST最大限制：<?php echo e(get_cfg_var("post_max_size")); ?><br>
                    服务器上传最大限制：<?php echo e(get_cfg_var("upload_max_filesize")); ?><br>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\快乐二级域名分发最新美化+商用源码，可对接易(码)支付\src\resources\views/admin/index.blade.php ENDPATH**/ ?>