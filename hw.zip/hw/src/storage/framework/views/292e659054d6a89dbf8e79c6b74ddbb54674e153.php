<?php $__env->startSection('title', '积分明细'); ?>
<?php $__env->startSection('content'); ?>
    <div id="vue">
        <div class="layui-card">
            <?php echo $__env->make('home.lkdns.layout.hand', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="layui-card">
            <div class="layui-tab layui-tab-brief ew-tab">
                <ul class="layui-tab-title">
                    <li class=""><a href="/home">解析记录</a></li>
                    <li class="layui-this"><a href="/home/point">积分明细</a></li>
                    <li class=""><a href="/home/recharge">积分充值</a></li>
                    <li class=""><a href="/home/profile">个人资料</a></li>
                    <li class=""><a href="/home/srv">SRV生成器</a></li>
                    <li class=""><a href="/home/hd">活动</a></li>
                </ul>
            </div>
            <div class="layui-card-body">
                <input type="text" disabled="disabled" class="d-none">
                <div class="layui-form-item">
                    <select class="layui-input" style="float:left;width:60%;" v-model="search.act">
                        <option value="all">所有</option>
                        <option value="increase">增加</option>
                        <option value="reduce">减少</option>
                        <option value="消费">消费</option>
                    </select>
                    <a class="layui-btn" style="color:#fff!important;float:right;width:35%;" @click="getList(1)">
                        搜索</a>
                </div>
                <div class="table-responsive">
                    <table class="layui-table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>操作</th>
                            <th>积分</th>
                            <th>剩余</th>
                            <th>详情</th>
                            <th>时间</th>
                        </tr>
                        </thead>
                        <tbody v-cloak="">
                        <tr v-for="(row,i) in data.data" :key="i"
                            :class="{'text-danger':row.point<0,'text-success':row.point>0}">
                            <td>{{ row.id }}</td>
                            <td>{{ row.action }}</td>
                            <td>{{ row.point }}</td>
                            <td>{{ row.rest }}</td>
                            <td>{{ row.remark }}</td>
                            <td>{{ row.created_at }}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
    <script>
        new Vue({
            el: '#vue',
            data: {
                search: {
                    page: 1, uid: $_GET('uid'), act: 'all'
                },
                data: {},
                storeInfo: {}
            },
            methods: {
                getList: function (page) {
                    var vm = this;
                    vm.search.page = typeof page === 'undefined' ? vm.search.page : page;
                    this.$post("/home", vm.search, {action: 'pointRecord'})
                        .then(function (data) {
                            if (data.status === 0) {
                                vm.data = data.data
                            } else {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            }
                        })
                },
            },
            mounted: function () {
                this.getList();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.lkdns.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/home/lkdns/point.blade.php ENDPATH**/ ?>