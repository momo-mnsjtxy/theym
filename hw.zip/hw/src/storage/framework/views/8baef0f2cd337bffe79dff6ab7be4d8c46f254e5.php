<?php $__env->startSection('title', '个人资料'); ?>
<?php $__env->startSection('content'); ?>
    <div id="vue">
        <div>
            <div class="layui-card">
                <div class="layui-card-body user-info-card">
                    <div class="user-info-top text-center layui-text">
                        <div class="user-info-head">
                            <img src="../ajax/libs/images/avatar.svg"/>
                        </div>
                        <h2><?php echo e(auth()->user()->username); ?> - [<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>

                            ]</h2>
                    </div>
                    <div class="user-info-list layui-text">
                        <div class="info-list-item" lay-tips="邮箱" lay-direction="4">
                            <i class="layui-icon layui-icon-username"></i>
                            <p><?php echo e(auth()->user()->email); ?></p>
                        </div>
                        <div class="info-list-item" lay-tips="积分" lay-direction="4">
                            <i class="layui-icon layui-icon-note"></i>
                            <p><?php echo e(auth()->user()->point); ?> 积分</p>
                        </div>
                        <div class="info-list-item" lay-tips="用户名" lay-direction="4">
                            <i class="layui-icon layui-icon-auz"></i>
                            <p><?php echo e(auth()->user()->username); ?></p>
                        </div>
                        <div class="info-list-item" lay-tips="用户组" style="min-height: 21px;" lay-direction="4">
                            <i class="layui-icon layui-icon-layer"></i>
                            <p><?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="layui-card">
                <div class="layui-tab layui-tab-brief ew-tab">
                    <ul class="layui-tab-title">
                        <li class=""><a href="../home">解析记录</a></li>
                        <li class=""><a href="../home/point">积分明细</a></li>
                        <li class="layui-this"><a href="../home/profile">个人资料</a></li>
                    </ul>
                </div>
                <div class="layui-card-body" style="box-sizing: border-box;padding-top: 5px;">
                    <br>
                    <form id="form-profile">
                        <input type="hidden" name="action" value="profile">
                        <div class="layui-form-item">
                            <label class="layui-form-label">状态:</label>
                            <div class="layui-input-block">
                                <div class="input-group">
                                    <select class="layui-input" style="background-color:#F5F5F5!important;"
                                            :value="<?php echo e(auth()->user()->status); ?>" disabled>
                                        <option value="0">已禁用</option>
                                        <option value="2">已认证</option>
                                        <option value="1">待认证</option>
                                    </select>
                                    <?php if(auth()->user()->status==1): ?>
                                        <span class="input-group-append" @click="verify">
<span class="input-group-text bg-info text-white">认证</span>
</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="layui-form-item">
                            <label class="layui-form-label">旧密码:</label>
                            <div class="layui-input-block">
                                <input type="password" name="old_password" class="layui-input" placeholder="输入旧密码">
                            </div>
                        </div>
                        <div class="layui-form-item">
                            <label class="layui-form-label">新密码:</label>
                            <div class="layui-input-block">
                                <input type="password" name="new_password" class="layui-input" placeholder="输入新密码">
                            </div>
                        </div>
                    </form>
                    <div class="layui-form-item" style="padding-top: 15px;">
                        <div class="layui-input-block text-center">
                            <a class="layui-btn layui-btn-primary" href="../home">首页</a>
                            <a class="layui-btn" style="color:#fff!important;" @click="form('profile')">保存</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <div class="ew-footer" style="max-width: 100vw;overflow: hidden;">
        <div class="layui-container">
            <div class="layui-row layui-col-space30">
                <div class="layui-col-md6">
                    <h2 style="font-size: 17px;" class="footer-item-title">关于我们</h2>
                    <p><span>Copyright© 2023 <?php echo e(config('sys.web.name')); ?> .all rights reserved.</span></p>
                </div>
                <div class="layui-col-md4">
                    <h2 style="font-size: 17px;" class="footer-item-title">联系我们</h2>
                    <p>
                        <i class="layui-icon layui-icon-login-qq"></i>
                        <a href="http://wpa.qq.com/msgrd?v=3&uin=3636066488&site=qq&menu=yes" target="_blank">咨询在线客服QQ:188974297</a>
                    </p>
                </div>
                <div class="layui-col-md2">
                    <h2 style="font-size: 17px;" class="footer-item-title">相关链接</h2>
                    <p><i class="layui-icon layui-icon-component"></i><a href="www.lkdns.top"
                                                                         target="_blank">灵空官网</a></p>
                </div>
            </div>
            <div style="padding: 15px 0!important;"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
    <script>
        new Vue({
            el: '#vue',
            data: {},
            methods: {
                verify: function () {
                    var vm = this;
                    this.$post("/home", {action: 'verify'})
                        .then(function (data) {
                            if (data.status === 0) {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                            action: function () {
                                                location.href = '../home/profile';
                                            }
                                        }
                                    }
                                });
                            } else {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            }
                        });
                },
                form: function (id) {
                    var vm = this;
                    this.$post("/home", $("#form-" + id).serialize())
                        .then(function (data) {
                            if (data.status === 0) {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                            action: function () {
                                                location.href = '../home/profile';
                                            }
                                        }
                                    }
                                });
                            } else {
                                $.confirm({
                                    title: '信息',
                                    icon: 'mdi mdi-information-outline',
                                    content: (data.message),
                                    type: 'blue',
                                    buttons: {
                                        omg: {
                                            text: '确定',
                                            btnClass: 'btn-blue',
                                        },
                                    }
                                });
                            }
                        });
                },
            },
            mounted: function () {
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.1.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\项目\php\dns\src\resources\views/home/1/profile.blade.php ENDPATH**/ ?>