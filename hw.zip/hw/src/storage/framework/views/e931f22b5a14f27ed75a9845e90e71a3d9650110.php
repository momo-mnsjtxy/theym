<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('sys.web.name')); ?></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/js/css/layui.css_v=204.css"/>
    <link rel="stylesheet" type="text/css" href="/css/main.css"/>
    <link rel="stylesheet" type="text/css" href="/css/nprogress.css">
    <link rel="stylesheet" href="https://unpkg.com/element-ui@2.15.14/lib/theme-chalk/index.css">
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
<div class="ew-header">
    <a class="layui-logo" href="/" style="letter-spacing: 1.5px;position: relative;text-decoration: none;">
        <img src="/images/logo-ico.png"
             style="width: 32px;height: 32px;position: absolute;top: 19px;left: 0;">
        <span><?php echo e(config('sys.web.name')); ?></span>
    </a>
    <div class="ew-nav-group" id="bq">
        <div class="nav-toggle"><i class="layui-icon layui-icon-more-vertical"></i></div>
        <ul class="layui-nav" lay-filter="ew-header-nav">
            <li class="layui-nav-item">
                <a href="/" style="text-decoration: none;">首页</a>
            </li>
            <li class="layui-nav-item">
                <a href="/home" style="text-decoration: none;"><?php echo e(auth()->user()->username); ?>

                    -<b>[<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>]</b></a>
            </li>
            <li class="layui-nav-item">
                <a href="/home/dh" style="text-decoration: none;">活动兑换</a>
            </li>
            <li class="layui-nav-item">
                <a href="/home/srv" style="text-decoration: none;">SRV生成器</a>
            </li>
            <li class="layui-nav-item nav-btn-login">
                <a class="dropdown-item" @click="sign()" style="text-decoration: none;">每日签到</a>
            </li>
            <li class="layui-nav-item nav-btn-login">
                <a href="/home/profile" style="text-decoration: none;">个人资料</a>
            </li>
            <li class="layui-nav-item nav-btn-login">
                <a href="/logout" style="text-decoration: none;"
                   onclick="return confirm('确认退出登录？');">退出登录</a>
            </li>
        </ul>
    </div>
</div>
<div class="layui-container body-card">
    <div class="layui-row layui-col-space15">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
</body>
<script src="/js/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/vue.min.js"></script>
<script src="/css/layer.js"></script>
<script type="text/javascript" src="/js/layui.js"></script>
<script src="/js/main.js"></script>
<script src="/js/nprogress.js"></script>
<script src="https://unpkg.com/element-ui@2.15.14/lib/index.js"></script>
<!--运行天数js
<script type="text/javascript">
    runtime();

    function runtime() {
        // 初始时间，日/月/年 时:分:秒
        X = new Date("12/25/2022 9:9:14");
        Y = new Date();
        T = (Y.getTime() - X.getTime());
        M = 24 * 60 * 60 * 1000;
        a = T / M;
        A = Math.floor(a);
        b = (a - A) * 24;
        B = Math.floor(b);
        c = (b - B) * 60;
        C = Math.floor((b - B) * 60);
        D = Math.floor((c - C) * 60);
        //信息写入到DIV中
        span.innerHTML = "本站已运行: " + A + "天" + B + "小时" + C + "分" + D + "秒"
    }

    setInterval(runtime, 1000);
</script>
运行天数js结束-->
<!--签到-->
<script>
    new Vue({
        el: '#bq',
        data: {},
        methods: {
            sign: function () {
                var vm = this;
                this.$post("/home", {action: 'sign'}).then(function (data) {
                    if (data.status === 0) {
                        vm.$notify({
                            title: '签到成功',
                            message: (data.message),
                            type: 'success',
                            duration: 3000,
                        });
                    } else {
                        vm.$notify.error({
                            title: '签到失败',
                            message: (data.message),
                            duration: 3000,
                        });
                    }
                })
            },
        },
    });
</script>
<!--签到结束-->
<script>
    NProgress.start();
    function neeprog() {
        NProgress.done();
    }
    window.onload = neeprog;
</script>
<script>
    var showMenu = false;
    $("#menu").click(function () {
        if (showMenu) {
            $(".bd-sidebar").removeClass('openMenu');
            $(".bd-content").removeClass('moveRight');
            $(".bd-content").addClass('moveAnimation');
            showMenu = false;
        } else {
            $(".bd-content").removeClass('moveAnimation');
            $(".bd-sidebar").addClass('openMenu');
            $(".bd-content").addClass('moveRight');
            showMenu = true;
        }
    });
</script>
<?php echo $__env->yieldContent('foot'); ?>
</html>
<?php /**PATH G:\项目\php\dns\src\resources\views/home/lkdns/layout/index.blade.php ENDPATH**/ ?>