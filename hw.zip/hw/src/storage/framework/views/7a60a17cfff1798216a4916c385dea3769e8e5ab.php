<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>SRV记录生成 - <?php echo e(config('sys.web.name','二级域名分发')); ?></title>
    <meta name="keywords" content="SRV记录生成,SRV记录,SRV,SRV记录解析,域名解析,SRV解析,SRV记录值生成,SRV生成生成,SRV记录生成,SRV解析生成,SRV生成器生成,SRV生成"/>
    <meta name="description" content="SRV生成器"/>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/all.min.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
</head>
<body style="background: linear-gradient(220.55deg, #B7DCFF 0%, #FFA4F6 100%)">
<header class="navbar navbar-expand navbar-dark flex-column flex-md-row bd-navbar bd-navbar-index">
    <a class="navbar-brand mr-0 mr-md-2" href="/" aria-label="Bootstrap">
        <img src="/images/logo.png" width="36" height="36">
    </a>

    <div class="navbar-nav-scroll">
        <ul class="navbar-nav bd-navbar-nav flex-row">
            <li class="nav-item">
                <a class="nav-link" href="/">首页</a>
            </li>
            <?php $__currentLoopData = \App\Helper::getIndexUrls(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a href="<?php echo e($url[1]); ?>" target="_blank" class="nav-link"><?php echo e($url[0]); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link active" href="/SRV">SRV生成器</a>
            </li>
        </ul>
    </div>
</header>
<main class="bd-masthead" id="col-12 py-md-3 pl-md-5 bd-content">
    <div class="container">
        <div class="row">
            <div class="col-12 py-md-3 pl-md-5">
                <div class="card mb-3">
                    <div class="bd-b card-header text-white bg-info">SRV生成器(无特殊均为小写)</div>
                    <div class="card-body">
                        <form id="form">
                            <div class="form-group text-center">
                                <div style="border: 1px solid rgb(206, 212, 218);border-radius: 0.25rem;padding: 0.375rem 0.75rem;margin-top: 0.25rem;font-size: 30px;color: grey;text-align: center;margin: 0 auto;width: 95%;">主机记录</div>
                            </div>
                            <div class="form-group row">
                                <label for="service" class="col-5 col-form-label">服务名(如:minecraft,frp,ssh)</label>
                                <div class="col-7">
                                    <input type="text" id="service" class="form-control" placeholder="输入服务名">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="protocol" class="col-5 col-form-label">协议名(如:tcp、udp)</label>
                                <div class="col-7">
                                    <input type="text" id="protocol" class="form-control" placeholder="输入协议名">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="alias" class="col-5 col-form-label">别名(即多级,如顶级使用@即可,不输入默认顶级)</label>
                                <div class="col-7">
                                    <input type="alias" id="alias" class="form-control" placeholder="输入别名">
                                </div>
                            </div>
                            <div class="form-group text-center">
                                <div style="border: 1px solid rgb(206, 212, 218);border-radius: 0.25rem;padding: 0.375rem 0.75rem;margin-top: 0.25rem;font-size: 30px;color: grey;text-align: center;margin: 0 auto;width: 95%;">记录值</div>
                            </div>
                            <div class="form-group row">
                                <label for="priority" class="col-5 col-form-label">优先级:(值越小，优先级越高)</label>
                                <div class="col-7">
                                    <input type="priority" id="priority" class="form-control" placeholder="输入优先级">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="weight" class="col-5 col-form-label">权重:(值越大,权重越大)</label>
                                <div class="col-7">
                                    <input type="weight" id="weight" class="form-control" placeholder="输入权重">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="port" class="col-5 col-form-label">端口号:(服务的端口,如ssh为22)</label>
                                <div class="col-7">
                                    <input type="port" id="port" class="form-control" placeholder="输入端口号">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="host" class="col-5 col-form-label">主机名:(目标主机的域名或ip。请确定可以访问)</label>
                                <div class="col-7">
                                    <input type="host" id="host" class="form-control" placeholder="输入目标主机名">
                                </div>
                            </div>
                            <div class="form-group text-center">
                                <a class="btn btn-info text-white" id="sc" href="#modal-srv" data-toggle="modal" @click="form('srv')"> 生 成 </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal-srv">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">生成完成</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="form-store">
                            <div class="form-group row">
                                <label for="h" class="col-sm-3 col-form-label">主机记录</label>
                                <div class="col-sm-7">
                                    <div class="input-group">
                                        <input type="text" name="hostte" id="hostte" class="form-control"v-model="storeInfo.h">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="staticEmail" class="col-sm-6 col-form-label">记录类型</label>
                                <div class="col-sm-5">
                                    <option value="SRV">SRV</option>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="record" class="col-sm-3 col-form-label">记录值</label>
                                <div class="col-sm-7">
                                    <input type="text" id="record" placeholder="" class="form-control" v-model="storeInfo.record">
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
                        <button type="button" class="btn btn-primary" @click="form('store')">确认</button>
                    </div>
                </div>
            </div>
        </div>
</main>

</body>
<script src="/js/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/vue.min.js"></script>
<script src="/js/layer.js"></script>
<script src="/js/main.js"></script>
<script type="text/javascript">
	window.onload = function(){
		var sc = document.getElementById("sc");
		sc.onclick = function(){
		    var a =document.getElementById("service").value;
		    var b = document.getElementById("protocol").value;
		    var c = document.getElementById("alias").value;
			var d = document.getElementById("hostte");
			if(a == ""){
			    d.value = "主机记录有内容为空哦"
			}else if(b==""){
			    d.value = "主机记录有内容为空哦"
			}else if(c===""){
			    d.value = "主机记录有内容为空哦"
			}else if(d===""){
			    d.value = "主机记录有内容为空哦"
			}else{
			    d.value = "_"+a+"._"+b + "."+c;
			}
			var e = document.getElementById("record")
			var f = document.getElementById("priority").value
			var j = document.getElementById("weight").value
			var h = document.getElementById("port").value
			var i = document.getElementById("host").value
			if(f === ""){
			    e.value = "记录值有内容为空哦"
			}else if(j===""){
			    e.value = "记录值有内容为空哦"
			}else if(h===""){
			    e.value = "记录值有内容为空哦"
			}else if(i===""){
			    e.value = "记录值有内容为空哦"
			}else{
			    e.value=f+" "+j+" "+h+" "+i+".";
			}

		}
	}
</script>
<script>
    new Vue({
        el: '#content',
        data: {
            act: 'login'
        },
        methods: {
            srv: function () {
            },
            form: function (id) {
                    var vm = this;
                    this.$post("/home", $("#form-" + id).serialize())
                        .then(function (data) {
                            if (data.status === 0) {
                                vm.getList();
                                $("#modal-" + id).modal('hide');
                                vm.$message(data.message, 'success');
                            } else {
                                vm.$message(data.message, 'error');
                            }
                        });
                },
        },
        mounted: function () {
            if ($_GET('zs') === 'zs') {
                this.act = 'zs';
            }
            var vm = this;
            document.onkeyup = function (e) {
                var code = parseInt(e.charCode || e.keyCode);
                if (code === 13) {
                    if (vm.act === 'zs') {
                        vm.reg();
                    } else {
                        vm.login();
                    }
                }
            }
        }
    });
</script>
</html>
<?php /**PATH G:\项目\php\dns\src\resources\views/srv.blade.php ENDPATH**/ ?>