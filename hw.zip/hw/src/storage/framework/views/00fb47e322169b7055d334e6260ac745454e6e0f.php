<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('sys.web.title',config('sys.web.name','网站首页'))); ?></title>
    <meta name="keywords" content="<?php echo e(config('sys.web.keywords')); ?>"/>
    <meta name="description" content="<?php echo e(config('sys.web.description')); ?>"/>
    <meta name="referrer" content="no-referrer" />
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/all.css" rel="stylesheet">
    <link href="/css/styles.min.css" rel="stylesheet" >
    <script src="/js/scripts.min.js"></script>
    <link href="/css/style.css" rel="stylesheet">
    <?php //<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3747818936581803" crossorigin="anonymous"></script>?>
    <script src="/css/vue.min.js"></script>
    <script src="/css/layer.js"></script>
    <script src="/js/main.js"></script>
</head>
<body>
		<div class="preloader">
			<div class="centrize full-width">
				<div class="vertical-center">
					<div class="spinner">
						<div class="double-bounce1"></div>
						<div class="double-bounce2"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="background gradient">
    	<ul class="bg-bubbles">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        </ul>
		</div>
		<div class="container opened" data-animation-in="fadeInLeft" data-animation-out="fadeOutLeft">
			<header class="header">
				<div class="top-menu">
					<ul>
						<li class="active">
							<a href="#about-card">
								<span class="icon fa fa-list-alt"></span>
								<span class="link">通告</span>
							</a>
						</li>
						<li>
							<a href="#resume-card">
								<span class="icon fas fa-briefcase"></span>
								<span class="link">条款</span>
							</a>
						</li>
						<li>
							<a href="#works-card">
								<span class="icon fas fa-paint-brush"></span>
								<span class="link">域名</span>
							</a>
						</li>
						<li>
							<a href="#blog-card">
								<span class="icon fas fa-heart"></span>
								<span class="link">捐献</span>
							</a>
						</li>
						<li>
							<a href="#contacts-card">
								<span class="icon fas fa-at"></span>
								<span class="link">关于</span>
							</a>
						</li>
						<li>
							<a href="/2">
								<span class="icon fas fa-sign-out"></span>
								<span class="link">旧版主页</span>
							</a>
						</li>
					</ul>
				</div>
			</header>

			<div class="card-started" id="home-card">
				<div class="profile">
					<div class="slide" style="background-image: url(<?php echo e(config('sys.web.sytpurl')); ?>);"></div>
					<div class="image">
						<img src="/images/logo-ico.png" alt="">
					</div>
					<div class="title"><?php echo e(config('sys.web.name')); ?></div>
					<div class="subtitle"><?php echo e(config('sys.web.url')); ?></div>
                    <div class="col-12 mt-0 mt-sm-3">
                    <form id="form-check">
                    <input type="text" class="d-none">
                    <div class="input-group">
                    <input type="text" class="form-control" style="height: 3rem" name="name"
                               placeholder="输入你想要的二级域名前缀">
                        <select name="did" class="form-control" style="flex: none;width: 100px;height: 3rem">
                            <?php $__currentLoopData = \App\Helper::getAvailableDomains(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($domain->did); ?>">.<?php echo e($domain->domain); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <div class="input-group-append">	</div>
                    <span class="input-group-text" style="background: #66CC99;color: white;"
                              onclick="check()">查询</span>
                  	</div>
                   	</div>
                    <?php if(auth()->check()): ?>
       	        	<div class="lnks" >
						<a   href="/home" class="lnk">
						<span class="text">解析记录</span>
						</a>
						<a  href="/logout" onclick="return confirm('确认退出登录？');" class="lnk">
							<span class="text" >退出登录</span>
						</a>
					</div>
			     	  <?php else: ?>
					<div class="lnks" >
						<a   href="/login2" class="lnk">
							<span class="text">登录</span>
						</a>
						<a  href="/login2?act=reg" class="lnk">
							<span class="text" >注册</span>

						</a>
					</div>
                      <?php endif; ?>
				</div>
			</div>

			<div class="card-inner animated active" id="about-card">
				<div class="card-wrap">
                   	<div class="content about">
						<div class="title">公告：</div>
						<div class="row">
							<div class="col col-d-12 col-t-12 col-m-12 border-line-v">
								<div class="text-box">
                             <?php echo config('sys.html_header'); ?>

                                </div>
					     	</div>
							<div class="clear"></div>
						</div>
					</div>

					<div class="content pricing">
						<div class="title">价格</div>
						<div class="row pricing-items">
							<div class="col col-d-6 col-t-6 col-m-12 border-line-v">
								<div class="pricing-item">
									<div class="icon"><i class="icon fas fa-cloud"></i></div>
									<div class="name">普通组</div>
									<div class="amount">
										<span class="dollar">￥</span>
										<span class="number">0.00</span>
										<span class="period">元</span>
									</div>
									<div class="feature-list">
										<ul>
											<li>每条解析5积分起</li>
											<li>未备案域名</li>
											<li class="disable">表白域名 <strong>new</strong></li>
											<li class="disable">edu域名<strong>new</strong></li>
											<li class="disable">更多ikun域名<strong>new</strong></li>
										</ul>
									</div>
										<div class="lnks">
										</div>
								</div>
							</div>

							<div class="col col-d-6 col-t-6 col-m-12 border-line-v">
								<div class="pricing-item">
									<div class="icon"><i class="icon fas fa-gem"></i></div>
									<div class="name">VIP</div>
									<div class="amount">
										<span class="dollar">￥</span>
										<span class="number"><?php echo e(config('sys.user.vip',0)); ?></span>
										<span class="period">元</span>
									</div>
									<div class="feature-list">
										<ul>
										    <?php echo config('sys.user.vipgn'); ?>

										</ul>
									</div>
									<div class="lnks">
									</div>
								</div>
							</div>
							<div class="clear"></div>
						</div>
				   	</div>
				</div>
			</div>
			<div class="card-inner" id="resume-card">
				<div class="card-wrap">
					<div class="content resume">
						<div class="title">条款</div>
						<div class="row">
							<div class="col col-d-6 col-t-6 col-m-12 border-line-v">
								<div class="resume-title border-line-h">
									<div class="icon"><i class="ion ion-person"></i></div>
									<div class="name">使用条款</div>
								</div>
								<div class="resume-items">
									<div class="resume-item border-line-h active">
										<div class="date">2021-2022</div>
										<div class="name">旗下域名不允许接入：伪造、钓鱼、诈骗、外挂、VPN、毒品、赌博、博彩、棋牌、彩票、虚假打赏、黄色、贷款、色情交友、盗版影视、不正常言论、不合法的信息收集、圈币等违规违法网站.</div>
										<div class="company"><?php echo e(config('sys.web.name')); ?>.</div>
									</div>
									<div class="resume-item border-line-h active">
										<div class="date">2021-2022</div>
										<div class="name">积分的充值与扣除中，都由站点根据使用情况合理调整人民币兑换积分的汇率！如有不满应当即在总换时当面提出.</div>
										<div class="company"><?php echo e(config('sys.web.name')); ?>.</div>
									</div>
									<div class="resume-item  border-line-h active">
										<div class="date">2021-2022</div>
										<div class="name">如您对网站做出有效操作就等同于默认同意以上条款.</div>
										<div class="company"><?php echo e(config('sys.web.name')); ?>.</div>
									</div>
								</div>
							</div>
							<div class="clear"></div>
						</div>

					</div>

				</div>
			</div>
			<div class="card-inner" id="works-card">
				<div class="card-wrap">
					<div class="content works">
						<div class="title">域名</div>
						<div class="row">
							<div class="col col-d-6 col-t-6 col-m-12 border-line-v">
								<div class="skills-list">
									<div class="skill-title border-line-h">
										<div class="icon"><i class="ion fas fa-cloud"></i></div>
										<div class="name">普通域名</div>
									</div>
									<ul>
										<li class="border-line-h">
											<div class="name">wdvip.me</div>
										</li>
										<li class="border-line-h">
											<div class="name">哎呦.tk</div>
										</li>
										<li class="border-line-h">
											<div class="name">梅素汁.gq</div>
										</li>
										<li class="border-line-h">
											<div class="name">你干嘛.ml</div>
										</li>
										<li class="border-line-h">
											<div class="name">小黑子.ml</div>
										</li>
										<li class="border-line-h">
											<div class="name">哎呦.tk</div>
										</li>
										<li class="border-line-h">
											<div class="name">ikkk.gq</div>
										</li>
										<li class="border-line-h">
											<div class="name">ikkun.ml</div>
										</li>
									</ul>
								</div>
							</div>
							<div class="col col-d-6 col-t-6 col-m-12 border-line-v">
								<div class="skills-list">
									<div class="skill-title border-line-h">
										<div class="icon"><i class="icon fas fa-gem"></i></div>
										<div class="name">VIP专属域名</div>
									</div>
									<ul>
										<li class="border-line-h">
											<div class="name">只因.tk</div>
										</li>
										<li class="border-line-h">
											<div class="name">你干嘛.tk</div>
										</li>
										<li class="border-line-h">
											<div class="name">真爱坤.ml</div>
										</li>
										<li class="border-line-h">
											<div class="name">小黑子.tk</div>
										</li>
										<li class="border-line-h">
											<div class="name">哎呦.tk</div>
										</li>
									    <li class="border-line-h">
											<div class="name">坤坤.gq</div>
										</li>
										<li class="border-line-h">
											<div class="name">爱坤.ml</div>
										</li>
										<li class="border-line-h">
											<div class="name">ikkk.gq</div>
										</li>
									</ul>
								</div>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="card-inner blog" id="blog-card">
				<div class="card-wrap">
					<div class="content blog">
						<div class="title">捐赠</div>
						<div class="row border-line-v">
							<div class="col col-d-12 col-t-12 col-m-12 border-line-h">
								<div class="box-item">
									<div class="image">
										<a >
											<img src="images\zfbhb.jpg" alt="">
										</a>
									</div>
									<div >
										<a class="name">用支付宝扫红包总换金币吧！</a>

									</div>
								</div>
							</div>
								<div class="col col-d-12 col-t-12 col-m-12 border-line-h">
								<div class="box-item">
									<div class="image">
										<a >
											<img src="images\wx.jpg" height="1000px" width="120px"  alt="">
										</a>
									</div>
									<div >
										<a  class="name">你倒是吃点菜啊，微信来点？微信</a>
									</div>
								</div>
							</div>
							<div class="col col-d-12 col-t-12 col-m-12 border-line-h">
								<div class="box-item">
									<div class="image">
										<a >
											<img src="images\zfb.jpg" alt="">

										</a>
									</div>
									<div >
										<a  class="name">能让我靓仔到六合一腹肌吗？支付宝</a>
									</div>
								</div>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="card-inner contacts" id="contacts-card">
				<div class="card-wrap">
					<div class="content contacts">
						<div class="title">关于</div>
						<div class="row">
							<div class="col col-d-12 col-t-12 col-m-12 border-line-v">
								<div class="info-list">
								<img src="/images/logo-ico.png"   height="110px" width="300px"  alt="" />
								</div>
								<div class="resume-item border-line-h active">
									<div class="date">2022</div>
									<div class="name">站长：征途</div>
									<div class="name"><a href="https://space.bilibili.com/353379484">站长B站: 征途wd</a></div>
									<div class="name">企鹅客服：1144552679</div>
								    <div class="name">站长邮箱：wdxbbj@gmail.com</div>
								    <div class="name">*有疑问请直接说明*</div>
									</div>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="content clients">
						<div class="title">旗下</div>
						<div class="row client-items">
							<div class="col col-d-3 col-t-3 col-m-6 border-line-v">
								<div class="client-item">
									<div class="image">
										<a target="_blank">
											<img src="链接" alt="">
										</a>
									</div>
								</div>
							</div>

							<div class="col col-d-3 col-t-3 col-m-6 border-line-v">
								<div class="client-item">
									<div class="image">
										<a target="_blank">
											<img src="链接" alt="">
										</a>
									</div>
								</div>
							</div>

							<div class="col col-d-3 col-t-3 col-m-6 border-line-v">
								<div class="client-item">
									<div class="image">
										<a target="_blank" >
											<img src="链接" alt="">
										</a>
									</div>
								</div>
							</div>

							<div class="col col-d-3 col-t-3 col-m-6 border-line-v">
								<div class="client-item">
									<div class="image">
										<a target="_blank" >
											<img src="链接" alt="">
										</a>
									</div>
								</div>
							</div>
					    	<div class="clear"></div>
					        	</div>
				                 	</div>
                 	                 <div class="content contacts">
		                           <div class="bg-white">
                                 <div class="content content-full text-center overflow-hidden">
                             <div class="py-50">
		               <h3 class="font-w700 mb-10"><?php echo e(config('sys.web.name')); ?> <i class="fa fa-heart text-danger"></i>
		               <a class="link-effect" href="https://www.wdvipa.com">征途博客</h3></a>
		               <?php echo e(config('app.name')); ?>

                      </div>
                       </div>
                            </div>

								</div>
							</div>
							<div class="clear"></div>
						</div>

					</div>

				</div>
			</div>

		</div>
	</div>
</body>
<script>
    function check() {
        $post("/check", $("#form-check").serialize())
            .then(function (data) {
                if (data.status === 0) {
                    layer.confirm(data.message, {
                        btn: ['解析', '取消']
                    }, function () {
                        window.location.href = "/home/"
                    }, function () {
                    });
                } else {
                    layer.alert(data.message)
                }
            });
    }

    document.onkeyup = function (e) {
        var code = parseInt(e.charCode || e.keyCode);
        if (code === 13) {
            check();
        }
    }
</script>
</html>
<?php /**PATH G:\项目\php\dns\src\resources\views/index.blade.php ENDPATH**/ ?>