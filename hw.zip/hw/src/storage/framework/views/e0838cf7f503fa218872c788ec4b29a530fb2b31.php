<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('sys.web.name')); ?></title>
    <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../ajax/libs/Easytpl/layui/css/layui.css_v=204.css"/>
    <link rel="stylesheet" type="text/css" href="../ajax/libs/Easytpl/css/main.css_v=204.css"/>
    <link rel="stylesheet" type="text/css" href="../ajax/libs/nprogress/nprogress.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="//static.i1r.cc/static/css/materialdesignicons.min.css">
    <link rel="stylesheet" type="text/css" href="//static.i1r.cc/static/js/jconfirm/jquery-confirm.min.css">
    <style>
        .user-info-form .layui-form-label {
            width: 100px;
        }

        .user-info-form .layui-input-block {
            margin-left: 130px;
        }

        .ele-download-group {
            padding: 38px 20px;
        }

        .ele-download-group > a {
            display: block;
            background: #1890ff;
            color: #fff;
            padding: 12px 0;
            text-align: center;
            transition: background-color .2s;
            line-height: 1.6;
        }

        .ele-download-group > a + a {
            margin-top: 20px;
        }

        .ele-download-group > a:hover {
            background: #096dd9;
        }

        .ele-download-group > a > span {
            display: block;
        }

        .product-card .product-body .product-title:hover {
            color: #1890ff;
        }

        .product-card:hover .product-cover > .product-cover-img {
            transform: none;
        }

        .product-card .product-cover > .product-tools,
        .product-card .product-cover:after,
        .product-card .product-body .layui-badge-rim {
            display: none;
        }

        .ew-banner {
            max-width: 100vw;
            overflow: hidden;
            background: #fff;
            color: #333;
            position: relative;
        }

        .ew-banner:before {
            display: none;
        }

        .ew-banner p {
            color: #999;
        }

        .ew-banner img.shape {
            -webkit-animation-duration: 5s;
            animation-duration: 5s;
        }

        .ew-banner img {
            pointer-events: none;
        }

        @media  screen and (max-width: 768px) {
            img.shape-main {
                width: 90% !important;
                max-width: 370px !important;
                right: 15px !important;
                top: 30px !important;
            }

            .ew-banner > .layui-container {
                padding-top: 320px;
                padding-bottom: 20px !important;
                padding-right: 20px !important;
            }

            img.shape6 {
                top: 510px !important;
            }

            img.shape4 {
                left: 5px !important;
                bottom: 300px !important;
            }

            .layui-logo > img {
                top: 12px !important;
            }

            .ew-footer .img-group {
                padding-left: 100px !important;
                height: 103px !important;
            }

            .ew-footer .img-group > img {
                width: 90px !important;
                height: 90px !important;
                top: 7px !important;
            }
        }

        .product-card .product-cover > .product-cover-img {
            background-position: 0 0;
        }

        .layui-elem-quote {
            border-radius: 4px;
        }

        .ele-price-hot-band {
            background: #ff9434;
            color: #fff;
            font-size: 12px;
            padding: 2px 0;
            text-align: center;
            transform: rotate(45deg);
            position: absolute;
            width: 120px;
            right: -30px;
            top: 16px;
        }

        .ew-footer-links {
            padding-bottom: 0;
        }

        .ew-footer-links p {
            line-height: 29px;
            white-space: nowrap;
        }

        .layui-input {
            border-radius: 3px !important;
        }
    </style>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>

<div class="ew-header">
    <a class="layui-logo" href="../" style="letter-spacing: 1.5px;position: relative;text-decoration: none;">
        <img src="../ajax/libs/Easytpl/images/logo.svg"
             style="width: 32px;height: 32px;position: absolute;top: 19px;left: 0;">
        <span><?php echo e(config('sys.web.name')); ?></span>
    </a>
    <div class="ew-nav-group" id="bq">
        <div class="nav-toggle"><i class="layui-icon layui-icon-more-vertical"></i></div>
        <ul class="layui-nav" lay-filter="ew-header-nav">
            <li class="layui-nav-item">
                <a href="../" style="text-decoration: none;">首页</a>
            </li>
            <li class="layui-nav-item">
                <a href="../home" style="text-decoration: none;"><?php echo e(auth()->user()->username); ?>

                    -<b>[<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>]</b></a>
            </li>
            <li class="layui-nav-item">
                <a href="../home" style="text-decoration: none;">解析记录</a>
            </li>
            <li class="layui-nav-item">
                <a href="../home/point" style="text-decoration: none;">积分明细</a>
            </li>
            <li class="layui-nav-item nav-btn-login">
                <a class="dropdown-item" @click="sign()" style="text-decoration: none;">每日签到</a>
            </li>
            <li class="layui-nav-item nav-btn-login">
                <a href="../home/profile" style="text-decoration: none;">个人资料</a>
            </li>
            <li class="layui-nav-item nav-btn-login">
                <a href="../logout" style="text-decoration: none;"
                   onclick="return confirm('确认退出登录？');">退出登录</a>
            </li>
        </ul>
    </div>
</div>
<div class="layui-container body-card">
    <div class="layui-row layui-col-space15">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
</div>
</div>
</body>
<script src="../ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="../ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="../ajax/libs/vue/2.6.10/vue.min.js"></script>
<script src="../ajax/libs/layer/2.3/layer.js"></script>
<script type="text/javascript" src="../ajax/libs/Easytpl/layui/layui.js"></script>
<script type="text/javascript" src="../ajax/libs/Easytpl/js/common.js_v=204"></script>
<script type="text/javascript" src="//static.i1r.cc/static/js/jconfirm/jquery-confirm.min.js"></script>
<script src="/js/main.js"></script>
<script type="text/javascript" src="../ajax/libs/nprogress/nprogress.js"></script>
<script>
    NProgress.start();

    function neeprog() {
        NProgress.done();
    }

    window.onload = neeprog;
</script>
<script>
    new Vue({
        el: '#bq', data: {data: {}, storeInfo: {}}, methods: {
            sign: function () {
                this.$post("/home", {action: 'sign'}).then(function (data) {
                    var vm = this;
                    if (data.status === 0) {
                        $.confirm({
                            title: '签到成功',
                            icon: 'mdi mdi-information-outline',
                            content: (data.message),
                            type: 'blue',
                            buttons: {
                                omg: {
                                    text: '确定',
                                    btnClass: 'btn-blue',
                                },
                            }
                        });
                    } else {
                        $.confirm({
                            title: '签到失败',
                            icon: 'mdi mdi-information-outline',
                            content: (data.message),
                            type: 'blue',
                            buttons: {
                                omg: {
                                    text: '确定',
                                    btnClass: 'btn-blue',
                                },
                            }
                        });
                    }
                })
            },
        },
    });
</script>
<script>
    var showMenu = false;
    $("#menu").click(function () {
        if (showMenu) {
            $(".bd-sidebar").removeClass('openMenu');
            $(".bd-content").removeClass('moveRight');
            $(".bd-content").addClass('moveAnimation');
            showMenu = false;
        } else {
            $(".bd-content").removeClass('moveAnimation');
            $(".bd-sidebar").addClass('openMenu');
            $(".bd-content").addClass('moveRight');
            showMenu = true;
        }
    });
</script>
<?php echo $__env->yieldContent('foot'); ?>
</html>
<?php /**PATH G:\项目\php\dns\src\resources\views/1/home/layout/index.blade.php ENDPATH**/ ?>