<?php $__env->startSection('title', '后台首页'); ?>
<?php $__env->startSection('content'); ?>
    <div id="vue" class="pt-3 pt-sm-0">
        <div class="card">
            <div class="card-header">
                快捷跳转
            </div>
            <div class="card-body">
                <div class="list-group-item">
                    <a href="/admin/config/dns">接口配置</a>
                </div>
                <div class="list-group-item">
                   ！
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/dns.wdvip.icu/src/resources/views/admin/index.blade.php ENDPATH**/ ?>