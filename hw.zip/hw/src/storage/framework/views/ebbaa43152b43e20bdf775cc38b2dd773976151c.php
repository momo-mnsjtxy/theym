<?php $__env->startSection('title', '卡密兑换'); ?>
<?php $__env->startSection('content'); ?>
<head>
    <meta charset="UTF-8">
    <title>卡密兑换</title>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/css.css" rel="stylesheet">
</head>
<body style="text-align:center;">
<div class="lyear-login">
  <div class="card-inner animated active" id="about-card">
    <div class="login-center">
    <h1>卡密兑换</h1>
      <form action="/dh/lq.php" method="post" name="form1">
        <table width="500" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td width="500" height="50" style="color:red;">
                卡密:<input class="form-control" type="text" name="user" size="12">
                用户名:<input class="form-control" type="text" name="pwd" id="pwd" size="12">
              <input type="submit" name="login" class="btn btn-block btn-success" value="兑换" />
          </tr>
        </table>
      </form>
    </div>
    <div class="col col-d-12 col-t-12 col-m-12 border-line-v">
        <div class="login-center">
            <h1>
                <a href="./" style="color: #89efa8;">返回</a>
            </h1>
        </div>
    </div>
  </div>
</div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/dns.wdvip.icu/src/resources/views/home/dh2.blade.php ENDPATH**/ ?>