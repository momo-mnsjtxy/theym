<div class="layui-card-body user-info-card">
    <div class="user-info-top text-center layui-text">
        <div class="user-info-head">
            <img src="/images/logo-ico.png"/>
        </div>
        <h2><?php echo e(auth()->user()->username); ?> - [<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>]</h2>
    </div>
    <div class="user-info-list layui-text">
        <div class="info-list-item" lay-tips="邮箱" lay-direction="4">
            <i class="layui-icon layui-icon-username"></i>
            <p><?php echo e(auth()->user()->email); ?></p>
        </div>
        <div class="info-list-item" lay-tips="积分" lay-direction="4">
            <i class="layui-icon layui-icon-note"></i>
            <p><?php echo e(auth()->user()->point); ?> 积分</p>
        </div>
        <div class="info-list-item" lay-tips="用户名" lay-direction="4">
            <i class="layui-icon layui-icon-auz"></i>
            <p><?php echo e(auth()->user()->username); ?></p>
        </div>
        <div class="info-list-item" lay-tips="用户组" style="min-height: 21px;" lay-direction="4">
            <i class="layui-icon layui-icon-layer"></i>
            <p><?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?></p>
        </div>
    </div>
</div>
<?php /**PATH G:\项目\php\dns\src\resources\views/home/lkdns/layout/hand.blade.php ENDPATH**/ ?>