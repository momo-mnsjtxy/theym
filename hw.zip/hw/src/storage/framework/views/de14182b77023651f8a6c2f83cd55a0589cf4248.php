<!doctype html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('sys.web.name')); ?></title>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/all.min.css" rel="stylesheet">
    <link href="/css/style.min.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <link href="/css/min.css" rel="stylesheet">
    <link href="/css/az.css" rel="stylesheet">
    <script type="text/javascript">
        function change(){
            var bodyBgs = [];
            bodyBgs[0] = "http://www.dmoe.cc/random.php";
            bodyBgs[1] = "http://www.dmoe.cc/random.php";
            bodyBgs[2] = "http://www.dmoe.cc/random.php";
            bodyBgs[3] = "http://www.dmoe.cc/random.php";
            bodyBgs[4] = "http://www.dmoe.cc/random.php";
            bodyBgs[5] = "http://www.dmoe.cc/random.php";
            bodyBgs[6] = "http://www.dmoe.cc/random.php";
            bodyBgs[7] = "http://www.dmoe.cc/random.php";
            bodyBgs[8] = "http://www.dmoe.cc/random.php";
            bodyBgs[9] = "http://www.dmoe.cc/random.php";
            bodyBgs[10] = "http://www.dmoe.cc/random.php";
            var randomBgIndex = Math.round( Math.random() * 10 );
            var img1= document.querySelector('html');
            img1.style.backgroundImage='url(' + bodyBgs[randomBgIndex] + ')';
            window.setTimeout(function(){change()},5000);}
        change();
    </script>
    <style>
        .lyear-wrapper {
            position: relative;
        }
        /* 电脑样式 */
        @media (min-width: 768px) {
            .lyear-login {
                display: flex;
                min-height: 100vh;
                align-items: center;
                justify-content: center;
            }

            .login-center {
                background: rgba(0, 0, 0, 0.3);
                border-radius: 28px;
                margin: 2.85714em auto; /* Center the login-center horizontally */
                min-width: 38.25rem;
                padding: 35px 40px 50px;
            }

        }

        /* Mobile Styles */
        @media (max-width: 767px) {
            .login-center {
                background: rgba(0,0,0,0.3);
                border-radius: 28px;
                margin: 2.85714em auto;
                max-width: 90%; /* Set a maximum width for the content */
                padding: 20px;
            }
            .lyear-login {
                max-width: 80%; /* Set the desired maximum width for lyear-login */
                margin: 0 auto; /* Center lyear-login horizontally */
                justify-content: space-between;
            }
            .bd-sidebar {
                width: 0;
                overflow: hidden;
                transition: width 0.3s ease;
                display: none;
            }
            .bd-sidebar.openMenu {
                display: block;
                width: 250px; /* Adjust the width as needed */
            }
            .bd-content.moveRight {
                margin-left: 0;
            }

            /* Adjust other mobile-specific styles here */

            /* Adjust font sizes if needed */
            h1 {
                font-size: 24px; /* Adjust the size as per your design */
            }
        }

        .login-header {
            margin-bottom: 1.5rem !important;
        }
        .login-center .has-feedback.feedback-left .form-control {
            padding-left: 38px;
            padding-right: 12px;
        }
        .login-center .has-feedback.feedback-left .form-control-feedback {
            left: 0;
            right: auto;
            width: 38px;
            height: 38px;
            line-height: 38px;
            z-index: 4;
            color: #dcdcdc;
        }
        .login-center .has-feedback.feedback-left.row .form-control-feedback {
            left: 15px;
        }
        .btn-success .btn-info {
            border-radius: 16px;
        }
        .btn-sm {
            border-radius: 14px;
        }
        h1 {
            color: #eee;
        }
    </style>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
<header class="navbar navbar-expand flex-md-row bd-navbar">
    <div class="navbar-nav-scroll">
        <ul class="navbar-nav bd-navbar-nav flex-row">
            <li class="nav-item d-sm-none" id="menu">
                <a class="nav-link nav-menu" href="#">
                    <i class="fa fa-bars fa-lg"></i>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link nav-logo-name" href="/"><i class="fa fa-cloud"></i><?php echo e(config('sys.web.name')); ?></a>
            </li>
        </ul>
    </div>

    <ul class="navbar-nav flex-row ml-auto d-md-flex" id="bq">
        <li class="nav-item dropdown">
            <a class="nav-item nav-link dropdown-toggle" href="#" id="user_btns"
               data-toggle="dropdown"><?php echo e(auth()->user()->username); ?>

                <span    class="d-none d-sm-inline">[<?php echo e(auth()->user()->group?auth()->user()->group->name:''); ?>]</span>
                <span    class="d-none d-sm-inline">[uid:<?php echo e(auth()->user()->uid); ?>]</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="user_btns" style="background-color: transparent; border-radius: 15px 15px 15px 15px;">
                <div class="dropdown-item" @click="sign()" style="background-color: rgba(255, 255, 255, 255); border-radius: 15px 15px 0 0;">每日签到</div>
                <a class="dropdown-item" href="/home/profile" style="background-color: rgba(255, 255, 255, 255);">修改密码</a>
                <a class="dropdown-item" href="/logout" style="background-color: rgba(255, 255, 255, 255);border-radius: 0 0 15px 15px;" onclick="return confirm('确认退出登录？');">退出登录</a>
            </div>
        </li>
    </ul>
</header>
<div class="container-fluid">
    <div class="row flex-xl-nowrap">
        <div class="col-12 col-md-3 col-xl-2 bd-sidebar">
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8); border-radius: 15px 15px 0 0;">
                <a href="/home/profile" class="menu-link">
                    <i class="fa fa-address-card"></i> 账户中心
                </a>
            </div>
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8);">
                <a href="/home" class="menu-link">
                    <i class="fa fa-globe"></i> 解析记录
                </a>
            </div>
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8);">
                <a href="/home/point" class="menu-link">
                    <i class="fa fa-cube"></i> 积分明细
                </a>
            </div>
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8);">
                <a href="/home/recharge" class="menu-link">
                    <i class="fa fa-credit-card fa-fw"></i> 积分充值
                </a>
            </div>
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8);">
                <a href="/home/km" class="menu-link">
                    <i class="fa fa-credit-card fa-fw"></i> 卡密兑换
                </a>
            </div>
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8);">
                <a href="/home/hd" class="menu-link" style="color:red;">
                    <i class="fa fa-credit-card fa-fw"></i> 限时活动
                </a>
            </div>
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8);">
                <a href="/home/jqun" class="menu-link" style="color:red;">
                    <i class="fas fa-address-book fa-fw"></i> 加群福利
                </a>
            </div>
            <div class="menu-item" style="background-color: rgba(255, 255, 255, 0.8); border-radius: 0 0 15px 15px;">
                <a href="/home/srv" class="menu-link" style="color:red;">
                    <i class="fa fa-american-sign-language-interpreting"></i> SRV生成器
                </a>
            </div>
        </div>
        <main class="col-12 col-md-9 col-xl-10 py-md-3 pl-md-5 bd-content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>
</body>
<script src="/js/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/vue.min.js"></script>
<script src="/js/layer.js"></script>
<script src="/js/main.js"></script>
<script>
    var showMenu = false;
    $("#menu").click(function () {
        if (showMenu) {
            $(".bd-sidebar").removeClass('openMenu');
            $(".bd-content").removeClass('moveRight');
            $(".bd-content").addClass('moveAnimation');
            showMenu = false;
        } else {
            $(".bd-content").removeClass('moveAnimation');
            $(".bd-sidebar").addClass('openMenu');
            $(".bd-content").addClass('moveRight');
            showMenu = true;
        }
    });
</script>
<script>
    new Vue({
        el: '#bq', data: {data: {}, storeInfo: {}}, methods: {
            sign: function () {
                this.$post("/home", {action: 'sign'}).then(function (data) {
                    var vm = this;
                    if (data.status === 0) {
                        layer.alert(data.message, {title: "签到成功"})
                    } else {
                        layer.alert(data.message, {title: "签到失败"})
                    }
                })
            },
        },
    });
</script>
<?php echo $__env->yieldContent('foot'); ?>
</html>
<?php /**PATH G:\项目\php\dns\src\resources\views/home/0/layout/index.blade.php ENDPATH**/ ?>