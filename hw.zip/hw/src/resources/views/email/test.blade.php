<center>
    <h1>测试邮件</h1>
    <p style="font-size: 12px;color: grey">测试邮件配置，收到此邮件说明邮箱配置成功！不是本人操作请勿略！</p>
</center>